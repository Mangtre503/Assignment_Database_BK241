

-- Create the stored procedure in the specified schema
CREATE PROCEDURE [dbo].[delete_class]
    @class_id BIGINT
AS
BEGIN
    BEGIN TRY

        -- Start transaction to ensure atomicity
        BEGIN TRANSACTION;

        -- Check if the class exists
        IF NOT EXISTS 
        (
            SELECT 1 
            FROM [dbo].[class] 
            WHERE [class_id] = @class_id
        )
            -- If the class does not exist, return an error
            THROW 50003, 'Class has been altered or deleted', 1;

        -- Delete the class from the table
        DELETE FROM [dbo].[class] 
        WHERE [class_id] = @class_id;

        -- Commit the transaction
        COMMIT TRANSACTION;

        -- PRINT 'Class with ID ' + CAST(@class_id AS VARCHAR) + ' has been successfully deleted.';

    END TRY

    BEGIN CATCH

        -- Rollback the transaction if an error occurs
        IF @@TRANCOUNT > 0 
            ROLLBACK TRANSACTION;

        -- For debugging as SA
        SELECT ERROR_LINE() AS [error line],
        ERROR_MESSAGE() AS [message],
        ERROR_NUMBER() AS [number],
        ERROR_PROCEDURE() AS [procedure],
        ERROR_SEVERITY() AS [severity],
        ERROR_STATE() AS [state];

        -- For application
        THROW;

    END CATCH
END;
go

