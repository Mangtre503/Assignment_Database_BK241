

-- Create the stored procedure in the specified schema
CREATE PROCEDURE update_class
    @class_id       BIGINT,
    @class_deposit  BIGINT = NULL,           -- Default NULL allows optional update
    @class_status   VARCHAR(255) = NULL,
    @commission_fee BIGINT = NULL,
    @requirements   VARCHAR(255) = NULL,
    @date_start     DATETIME2(7) = NULL,
    @salary         BIGINT = NULL,
    @addr_id        BIGINT = NULL,           -- This is NOT NULL, so optional update logic is important
    @student_id     BIGINT = NULL,           -- This is NOT NULL, so optional update logic is important
    @ts_id          BIGINT = NULL,           -- This is NOT NULL, so optional update logic is important
    @tutor_id       BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;
        -- Update the class
        -- ISNULL() is used for optional update
        UPDATE dbo.class
        SET 
            class_deposit =     ISNULL(@class_deposit, class_deposit),
            class_status =      ISNULL(@class_status, class_status),
            commission_fee =    ISNULL(@commission_fee, commission_fee),
            requirements =      ISNULL(@requirements, requirements),
            date_start =        ISNULL(@date_start, date_start),
            salary =            ISNULL(@salary, salary),
            addr_id =           ISNULL(@addr_id, addr_id),       
            student_id =        ISNULL(@student_id, student_id), 
            ts_id =             ISNULL(@ts_id, ts_id),             
            tutor_id =          ISNULL(@tutor_id, tutor_id)
        WHERE class_id = @class_id;

        -- If no rows were affected, class_id might not exist
        IF @@ROWCOUNT = 0
        BEGIN 
            ROLLBACK TRANSACTION;
            RETURN;
        END 

        -- Commit the transaction
        COMMIT TRANSACTION;

    END TRY

    BEGIN CATCH

        -- Roll back the transaction if any error occurs
        IF @@TRANCOUNT > 0 
            ROLLBACK TRANSACTION;

        -- For debugging as SA
        SELECT ERROR_LINE() AS [error line],
        ERROR_MESSAGE() AS [message],
        ERROR_NUMBER() AS [number],
        ERROR_PROCEDURE() AS [procedure],
        ERROR_SEVERITY() AS [severity],
        ERROR_STATE() AS [state];

        -- For application
        THROW;
    END CATCH
END;
go

