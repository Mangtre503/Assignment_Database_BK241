

CREATE PROCEDURE dbo.insert_class
    @class_deposit      BIGINT,
    @class_status       VARCHAR(255) = 'Chua giao',
    @commission_fee     BIGINT,
    @requirements       VARCHAR(255),
    @date_start         DATETIME2(7),
    @salary             BIGINT,
    @addr_id            BIGINT,
    @student_id         BIGINT,
    @ts_id              BIGINT,
    @tutor_id           BIGINT = NULL,
    @inserted_class_id  BIGINT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY

        -- Validation for addr_id
        IF @addr_id IS NULL
            THROW 50001, 'An address is needed', 1;

        -- Validation for student_id
        IF @student_id IS NULL 
            THROW 50007, 'Class must have a student', 1;

        -- Validation for simple business logic
        IF @class_deposit > @salary
            THROW 50002, 'The deposit must be less than the salary', 1;

        -- Validation for class_style
        IF @ts_id IS NULL 
            THROW 50008, 'Class must have a class style', 1;

        -- Validation that the address of the class
        -- must belong to the student in the class
        -- [a student can have multiple address]
        IF 
        (
            @addr_id NOT IN 
            (
                -- All addresses of student
                SELECT a.addr_id
                FROM dbo.address a 
                WHERE a.user_id = @student_id
            )
        )
            THROW 50009, 'Student does not have the address', 1;


        INSERT INTO dbo.class
        (
            class_deposit, class_status, commission_fee, 
            requirements, date_start, salary, 
            addr_id, student_id, ts_id, tutor_id
        )
        -- return the class_id
        -- OUTPUT inserted.class_id INTO @inserted_class_id

        VALUES
        (
            @class_deposit, @class_status, @commission_fee, 
            @requirements, @date_start, @salary, 
            @addr_id, @student_id, @ts_id, @tutor_id
        );

        SET @inserted_class_id = SCOPE_IDENTITY();

    END TRY 

    BEGIN CATCH

        -- For debugging as SA
        SELECT ERROR_LINE() AS [error line],
        ERROR_MESSAGE() AS [message],
        ERROR_NUMBER() AS [number],
        ERROR_PROCEDURE() AS [procedure],
        ERROR_SEVERITY() AS [severity],
        ERROR_STATE() AS [state];

        -- For application
        THROW;

    END CATCH 
END
go

